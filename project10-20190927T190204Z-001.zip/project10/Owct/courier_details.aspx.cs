﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public partial class courier_details : System.Web.UI.Page
{
   // SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project7\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);

    SqlCommand cmd,cmd2;
    SqlDataAdapter da,da2;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cusid"] != null)
        {

            txtcusid.Text = Session["cusid"].ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("select * from tblcourier where cus_id="+txtcusid.Text+"", con);
        da = new SqlDataAdapter(cmd);
        // DataTable dt = new DataTable();
        ds = new DataSet();
        da.Fill(ds, "tblcourier");
        gdvcourier.DataSource = ds.Tables[0];
        gdvcourier.DataBind();
        con.Close();
    }
    protected void gdvcourier_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr = gdvcourier.SelectedRow;
        txtcourierid.Text = gr.Cells[1].Text;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd2 = new SqlCommand("select t_id,current_status,date  from tblstatustrack where cr_id=" + txtcourierid.Text + "", con);
        da2 = new SqlDataAdapter(cmd2);
        // DataTable dt = new DataTable();
        ds = new DataSet();
        da2.Fill(ds, "tblstatustrack");
        gdvstatus.DataSource = ds.Tables[0];
        gdvstatus.DataBind();
        con.Close();
    }
}