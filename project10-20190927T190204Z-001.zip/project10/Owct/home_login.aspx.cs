﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;




public partial class home_login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);
     //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project7\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
    protected void Page_Load(object sender, EventArgs e)
    {
      
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      
        if (ddllogin.SelectedItem.Value=="Admin")
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tbladmin where Id='" + txtuserid.Text + "' and pass='" + txtpass.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmd.ExecuteNonQuery();
            if (dt.Rows.Count > 0)
            {
               
                MessageBox.Show("welcome admin");
                //string name = txtuserid.Text.Trim();
                //Session["name"] = name;
                 Response.Redirect("admin_o.aspx");
            }
            else
            {
                // Response.Redirect(".aspx");
                MessageBox.Show(" not welcome");
            }
            con.Close();
         
        }
        else if (ddllogin.SelectedItem.Value == "User")
        {
            con.Open();
            SqlCommand cmd2 = new SqlCommand("select * from tblcusdetails where cus_mob='" + txtuserid.Text + "' and pass='" + txtpass.Text + "'", con);
            SqlCommand cmd10;
            cmd10 = new SqlCommand("select cus_id from tblcusdetails where cus_mob='" + txtuserid.Text + "'",con);
            Session["cusid"] = cmd10.ExecuteScalar();
            SqlDataAdapter sda2 = new SqlDataAdapter(cmd2);
            DataTable dk = new DataTable();
            sda2.Fill(dk);
            cmd2.ExecuteReader();
            if (dk.Rows.Count > 0)
            {
               
                MessageBox.Show("welcome User");
               // string name = txtuserid.Text.Trim();
               // Session["name"] = name;
                Response.Redirect("cus_booking.aspx");
               // Response.Write("Welcome",name);
            }
            else
            {
                // Response.Redirect(".aspx");
                MessageBox.Show(" not welcome");
            }
        }
        else
        {
            MessageBox.Show(" choise not proper");
        }
    }
    protected void txtuserid_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnnew_Click(object sender, EventArgs e)
    {
        Response.Redirect("cus_registration.aspx");
    }
}