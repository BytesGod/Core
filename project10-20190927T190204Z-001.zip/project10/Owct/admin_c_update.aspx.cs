﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);
    SqlCommand cmd,cmd2;
    SqlDataAdapter sda,sda2;
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("select cr_id,s_name,s_city,r_name,r_city from tblcourier ",con);
        sda = new SqlDataAdapter(cmd);
        sda.Fill(ds, "tblcouier");
        gvdupdate.DataSource = ds.Tables[0];
        gvdupdate.DataBind();
        con.Close();
    }
    protected void gvdupdate_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr = gvdupdate.SelectedRow;
        txtid.Text = gr.Cells[1].Text;
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd2 = new SqlCommand("insert into tblstatustrack values('"+txtid.Text+"','"+txtstatus.Text+"','"+txtdate.Text+"')",con );
        sda2 = new SqlDataAdapter(cmd2);
        cmd2.ExecuteNonQuery();
        con.Close();

    }
}