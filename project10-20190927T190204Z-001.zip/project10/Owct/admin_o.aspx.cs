﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_o : System.Web.UI.Page
{
   // SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project7\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);

    SqlCommand cmd, cmd2, cmd3;
    SqlDataAdapter da, da2, da3;
    DataSet ds, ds2, ds3;
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        {
            con.Open();
            cmd = new SqlCommand("select * from tblmanagers", con);
            da = new SqlDataAdapter(cmd);
            // DataTable dt = new DataTable();
            ds = new DataSet();
            da.Fill(ds, "tblmanager");
            gdv.DataSource = ds.Tables[0];
            gdv.DataBind();
            con.Close();
        }

    }
    protected void gdv_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btninsert_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into tblmanagers values('" + txtid.Text + "','" + txtpass.Text + "','" + txtname.Text + "','" + txtcity.Text + "','" + txtstate.Text + "','" + txtpin.Text + "')", con);
        da = new SqlDataAdapter(cmd);
        cmd.ExecuteNonQuery();
        lblmsg.Text = "New Row Inserted Successfully";
        //SqlDataSource1.DataBind();
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
        Response.Redirect("admin_o.aspx");
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd2 = new SqlCommand("Update tblmanagers set manager_pass='" + txtpass.Text + "',manager_name='" + txtname.Text + "',manager_city='" + txtcity.Text + "',manager_state='" + txtstate.Text + "',manager_pincode='" + txtpin.Text + "' where manager_id=" + Convert.ToInt32(txtid.Text).ToString() + "", con);
        da2 = new SqlDataAdapter(cmd2);
        cmd2.ExecuteNonQuery();
        lblmsg.Text = "New Row Updated Successfully";
        //SqlDataSource1.DataBind();
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
        Response.Redirect("admin_o.aspx");
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd3 = new SqlCommand("delete from tblmanagers  where manager_id='" + txtid.Text + "'", con);
        da3 = new SqlDataAdapter(cmd3);
        cmd3.ExecuteNonQuery();
        lblmsg.Text = "Row Deleted Successfully";
        //SqlDataSource1.DataBind();
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
        Response.Redirect("admin_o.aspx");
    }
    protected void btnlogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("home_login.aspx");
    }
}