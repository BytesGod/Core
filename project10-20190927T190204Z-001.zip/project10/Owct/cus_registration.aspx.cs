﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class cus_registration : System.Web.UI.Page
{
    // SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project7\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);
    SqlCommand cmd, cmd2, cmd3;
    SqlDataAdapter da, da2, da3;
    DataSet ds, ds2, ds3;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into tblcusdetails values('" + txtname.Text + "','" + txtmob.Text + "','" + txtemail.Text + "','" + txtpass.Text + "','" + txtconpass.Text + "')",con);
        da = new SqlDataAdapter(cmd);
        cmd.ExecuteNonQuery();
        //lblmsg.Text = "New Row Inserted Successfully";
        //SqlDataSource1.DataBind()
        con.Close();
        Response.Write("enter successfully");
        Response.Redirect("home_login.aspx");
    }
}