﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;

public partial class courier_status : System.Web.UI.Page
{
  //  SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project7\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);
    SqlCommand cmd, cmd2;
    SqlDataAdapter sda, sda2;
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cusid"] != null)
        {

            txtstatus.Text = Session["cusid"].ToString();
        }
    }
    protected void btnsearch_Click(object sender, EventArgs e)
    {

    }
    protected void btnsearch_Click1(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand(" select tblcourier.cr_id,tblcourier.s_name,tblcourier.s_city,tblcourier.r_name,tblcourier.r_city,tblcourier.date,tblstatustrack.current_status,tblstatustrack.date from tblcourier,tblstatustrack where tblcourier.cr_id='" + txtstatus.Text + "'", con);
        sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(ds, "dt");
        gdvsearch.DataSource = ds.Tables[0];
        gdvsearch.DataBind();
        con.Close();


    }
}