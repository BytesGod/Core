﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class cus_booking : System.Web.UI.Page
{
     //SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project7\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
     SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["myowct"].ConnectionString);
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["cusid"] != null)
        {

            txtcusid.Text = Session["cusid"].ToString();
        }
    }
    protected void txtweight_TextChanged(object sender, EventArgs e)
    {
        
    }
    protected void btnamount_Click(object sender, EventArgs e)
    {
        int take, give;
        take = int.Parse(txtweight.Text);
        give = take * 100;
        txtamount.Text = give.ToString();
       //   txtcusid.Text=
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into tblcourier values('" + txt_s_name.Text + "','" + txt_s_add.Text + "','" + ddl_s_state.SelectedItem.Text + "','" + ddl_s_city.SelectedItem.Text + "','" + txt_s_pin.Text + "','" + txt_r_name.Text + "','" + txt_r_add.Text + "','" + ddl_r_state.SelectedItem.Text + "','" + ddl_r_city.SelectedItem.Text + "','" + txt_r_pin.Text + "','" + txtweight.Text + "','" + txtamount.Text + "','" + txtdate.Text + "','" + txtcusid.Text + "')", con);
        da = new SqlDataAdapter(cmd);
        cmd.ExecuteNonQuery();
        //lblmsg.Text = "New Row Inserted Successfully";
        //SqlDataSource1.DataBind()
        con.Close();
        Response.Write("enter successfully");
    }
}