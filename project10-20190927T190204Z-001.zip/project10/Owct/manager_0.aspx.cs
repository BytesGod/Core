﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;



public partial class manager_0 : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\h\Desktop\project3\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");
    //SqlConnection con = new SqlConnection(@" Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\SRKI-035\Desktop\project2\Owct\App_Data\dbowct.mdf;Integrated Security=True;Connect Timeout=30");

    SqlCommand cmd, cmd2, cmd3;
    SqlDataAdapter da, da2, da3;
    DataSet ds, ds2, ds3;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        cmd = new SqlCommand("select * from tblstaffdetails", con);
        da = new SqlDataAdapter(cmd);
        // DataTable dt = new DataTable();
        ds = new DataSet();
        da.Fill(ds, "tblstaffdetails");
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
    }
    protected void btninsert_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into tblstaffdetails values('" + txtid.Text + "','" + txtpass.Text + "','" + txtname.Text + "','" + txtlname.Text + "','" + txtemail.Text + "','" + txtmob.Text + "','" + txtadd.Text + "','" + txtcity.Text + "','" + txtcity.Text + "')", con);
        da = new SqlDataAdapter(cmd);
        cmd.ExecuteNonQuery();
        lblmsg.Text = "New Row Inserted Successfully";
        //SqlDataSource1.DataBind();
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
        Response.Redirect("manager_0.aspx");
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd2 = new SqlCommand("Update tblstaffdetails set staff_pass='" + txtpass.Text + "',F_name='" + txtname.Text + "',L_name='" + txtlname.Text + "',staff_Email='" + txtemail.Text + "',staff_mob='" + txtmob.Text + "',staff_add='" + txtadd.Text + "',staff_city='" + txtcity.Text + "',staff_pincode='" + txtcity.Text + "' where staff_id=" + Convert.ToInt32(txtid.Text).ToString() + "", con);
        da2 = new SqlDataAdapter(cmd2);
        cmd2.ExecuteNonQuery();
        lblmsg.Text = "New Row Updated Successfully";
        //SqlDataSource1.DataBind();
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
        Response.Redirect("manager_0.aspx");
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        con.Open();
        cmd3 = new SqlCommand("delete from tblstaffdetails  where staff_id='" + txtid.Text + "'", con);
        da3 = new SqlDataAdapter(cmd3);
        cmd3.ExecuteNonQuery();
        lblmsg.Text = "Row Deleted Successfully";
        //SqlDataSource1.DataBind();
        gdv.DataSource = ds.Tables[0];
        gdv.DataBind();
        con.Close();
        Response.Redirect("manager_0.aspx");
    }

    protected void btnlogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("home_login.aspx");
    }
    protected void txtmob_TextChanged(object sender, EventArgs e)
    {

    }
}