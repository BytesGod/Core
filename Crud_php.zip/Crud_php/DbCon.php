<?php

class DbCon
{
    private $host = "localhost";
    private $user = "root";
    private $password = "";
    private $dbname = "PHP_OOP_CRUD";
    
    protected $con;
    
    public function __construct() {
        if(!isset($this->con)){
            $this->con = mysqli_connect($this->host, $this->user, $this->password, $this->dbname);
            
            if(!$this->con){
                echo "Can't connect to database server.";
                exit();
            }
            else
            {
                echo "Connected.";
            }
        }
        return $this->con;
    }
}
?>