<?php

include_once 'Operation.php';

$operation = new Operation();

$query = "select * from customer";

$result = $operation->select($query);

?>


<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Add Data</title>
    </head>
    <body>
        <a href="ViewRecord.php">Home</a>
        
        <form action="AddData.php" method="POST">
            <table border="0">
                <tr>
                    <td>Product Name</td>
                    <td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td>Order Quantity</td>
                    <td><input type="text" name="quantity"></td>
                </tr>
                <tr>
                    <td>Order Price</td>
                    <td><input type="text" name="price"></td>
                </tr>
                <tr>
                    <td>Customer Name</td>
                    <td>
                        <select>
                            <option value="-1" name="select">Select Customer Name</option>
                        <?php
                        foreach ($result as $key=>$res)
                        {
                            echo "<option value=".$res['cust_id']."name=".$res['cust_id'].">".$res['cust_name']."</option>";
                        }
                        ?>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td></td>
                    <td><input type="submit" name="submit" value="AddData"></td>
                </tr>
            </table>

        </form>
        
    </body>
</html>