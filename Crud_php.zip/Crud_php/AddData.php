<?php

include_once 'Operation.php';

$operation = new Operation();

if(isset($_POST['submit']))
{
    $name = $operation->escapeString($_POST['name']);
    $price = $operation->escapeString($_POST['price']);
    $quantity = $operation->escapeString($_POST['quantity']);
    $id = $operation->escapeString($_POST['cust_id']);
    $date = date('m/d/Y h:i:s', time());
    
    $query = "insert into order1(Name, quantity,price,cust_id,order_created) values('$name', $quantity,$price,$id,$date)";
    
    $result = $operation->executeQuery($query);
    if($result){
        echo "<font color='green'>Added Successfully";
        echo "<br/><a href='index.php'>View Data</a>";
        header("Location:index.php");
    }
    else{
        echo "<font color='red'>Added Successfully";
    }
}
?>
