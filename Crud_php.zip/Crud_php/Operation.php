<?php

include_once 'DbCon.php';

class Operation extends DbCon
{
    public function __construct() {
        parent::__construct();
    }
    
    public function select($query)
    {
        $result = mysqli_query($this->con, $query);
        
        if(!$result){
            echo "Error in Crud Select.";
            return false;
        }
        
        $rows = array();
        
        while($row = $result->fetch_array())
        {
            $rows[] = $row;
        }
        return $rows;
    }
    
    public function executeQuery($query)
    {
        $result = mysqli_query($this->con,$query);
        
        if(!$result){
            echo "Error Can't execute query.";
            return false;
        }
        else{
            return true;
        }
    }
    
    public function delete($id, $table)
    {
        $query = "delete from $table where ID = $id";
        echo $query;
        $result = mysqli_query($this->con, $query);
        
        if(!$result){
            echo "Error : can't delete ".$id." from table ".$table;
            return false;
        }
        else{
            return true;
        }
            
    }
    
    public function escapeString($value)
    {
        return $this->con->real_escape_string($value);
    }
}

?>