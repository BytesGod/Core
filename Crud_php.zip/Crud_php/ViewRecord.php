<?php

include_once 'Operation.php';

$operation = new Operation();

$query = "select * from order1";

$result = $operation->select($query);

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>View Data</title>
    </head>
    <body>
        <a href="Add.php">Add Data</a>
        
        <table border="0">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Product Name</th>
                    <th>Order Quantity</th>
                    <th>Order Price</th>
                    <th>Customer ID</th>
                    <th>Order Created</th>
                </tr>
            </thead>
            <?php
            
            foreach($result as $key=>$res)
            {
                echo "<tbody>";
                    echo "<tr>";
                        echo "<td>".$res['order_id']."</td>";
                        echo "<td>".$res['prod_name']."</td>";
                        echo "<td>".$res['order_quantity']."</td>";
                        echo "<td>".$res['order_price']."</td>";
                        echo "<td>".$res['cust_id']."</td>";
                        echo "<td>".$res['order_created']."</td>";
                    echo "</tr>";
                echo "</tbody>";
            }
            ?>
        </table>

        <?php
            
        ?>
    </body>
</html>