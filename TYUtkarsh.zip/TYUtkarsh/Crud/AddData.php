<?php

include_once 'Crud.php';

$crud = new Crud();

if(isset($_POST['submit']))
{
    $name = $crud->escapeString($_POST['name']);
    $email = $crud->escapeString($_POST['email']);
    $mobile = $crud->escapeString($_POST['mobile']);
    
    $query = "insert into tbluser(Name, Email, Mobile) values('$name', '$email', $mobile)";
    
    $result = $crud->executeQuery($query);
    if($result){
        echo "<font color='green'>Added Successfully";
        echo "<br/><a href='index.php'>View Data</a>";
        header("Location:index.php");
    }
    else{
        echo "<font color='red'>Added Successfully";
    }
}
?>

