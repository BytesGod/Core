<?php

include_once 'Crud.php';

$crud = new Crud();

$query = "select * from tbluser";

$result = $crud->select($query);

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>View Data</title>
    </head>
    <body>
        <a href="Add.php">Add Data</a>
        
        <table border="0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Update</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <?php
            
            foreach($result as $key=>$res)
            {
                echo "<tbody>";
                    echo "<tr>";
                        echo "<td>".$res['ID']."</td>";
                        echo "<td>".$res['Name']."</td>";
                        echo "<td>".$res['Email']."</td>";
                        echo "<td>".$res['Mobile']."</td>";
                        echo "<td><a href=\"Update.php?id=$res[ID]\">Edit</a></td>";
                        echo "<td><a href=\"Delete.php?id=$res[ID]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
                    echo "</tr>";
                echo "</tbody>";
            }
            ?>
        </table>

        <?php
            
        ?>
    </body>
</html>
