<?php

include_once 'Crud.php';

$crud = new Crud();

$id = $crud->escapeString($_GET['id']);

$query = "select * from tbluser where ID = $id";

$result = $crud->select($query);

foreach($result as $key=>$res)
{
    $name = $res['Name'];
    $email = $res['Email'];
    $mobile = $res['Mobile'];
}

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="index.php">Home</a>
        
        <form action="UpdateData.php" method="POST">
            <table border="0">
                <tr>
                    <td></td>
                    <td><input type="hidden" name="id" value="<?php echo $id?>"></td>
                </tr>
                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name" value="<?php echo $name?>"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email" value="<?php echo $email?>"></td>
                </tr>
                <tr>
                    <td>Mobile</td>
                    <td><input type="text" name="mobile" value="<?php echo $mobile?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="update" value="Update"></td>
                </tr>
            </table>

        </form>
    </body>
</html>
