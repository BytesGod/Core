﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] != null)
        {
            lblWelcome.Text = "Welcome " + Session["Username"].ToString();
            lbLogin.Text = "Logout";
            hypSignUp.Visible = false;
            hypChangePass.Visible = false;
        }
    }
    protected void lbLogin_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("~/Student/Login.aspx");
    }
}
