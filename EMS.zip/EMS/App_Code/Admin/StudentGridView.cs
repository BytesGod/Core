﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
/// <summary>
/// Summary description for StudentGridView
/// </summary>
public class StudentGridView
{
	public StudentGridView()
	{
		
	}
    public partial class tblStudent
    {
        public int StudId { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public long Mobile { get; set; }
        public string GraduationType { get; set; }
        public string Course { get; set; }
        public string Class { get; set; }
        public string ImageName { get; set; }
        public Nullable<int> Size { get; set; }
        public byte[] ImageData { get; set; }
        public string DOB { get; set; }
        public Nullable<int> RetryAttempt { get; set; }
        public Nullable<bool> IsLocked { get; set; }
        public Nullable<System.DateTime> LockedDateTime { get; set; }
    }
    public static List<tblStudent> GetAllStudent()
    {
        List<tblStudent> listStudent = new List<tblStudent>();

        string CS = ConfigurationManager.ConnectionStrings["EMSConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            SqlCommand cmd = new SqlCommand("select StudId,FName,LName,Username,Password,Email,Mobile,GraduationType,Course,Class,ImageName,Size,ImageData,DOB,RetryAttempt from tblStudent", con);
            con.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                tblStudent student = new tblStudent();
                student.StudId = Convert.ToInt32(rdr["StudId"]);
                student.FName = rdr["FName"].ToString();
                student.LName = rdr["LName"].ToString();
                student.Username = rdr["Username"].ToString();
                student.Password = rdr["Password"].ToString();
                student.Email = rdr["Email"].ToString();
                student.Mobile = Convert.ToInt64(rdr["Mobile"]);
                student.GraduationType = rdr["GraduationType"].ToString();
                student.Course = rdr["Course"].ToString();
                student.Class = rdr["Class"].ToString();
                student.DOB = rdr["DOB"].ToString();
                //student.IsLocked = Convert.ToBoolean(rdr["IsLocked"]);
                //student.DOB = System.DateTime<(rdr["LockedDateTime"])>;
                listStudent.Add(student);
            }
        }

        return listStudent;
    }
}