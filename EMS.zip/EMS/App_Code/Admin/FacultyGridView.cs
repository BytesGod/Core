﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FacultyGridView
/// </summary>
public class FacultyGridView
{
	public FacultyGridView()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}