﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Drawing;
using System.Net.Mail;
using System.Web.Security;

public partial class Admin_AddUser_AddFaculty : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSRegistration_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            HttpPostedFile postedFile = fupSImage.PostedFile;
            string filename = Path.GetFileName(postedFile.FileName);
            string fileExtension = Path.GetExtension(filename);
            int fileSize = postedFile.ContentLength;

            if (fileExtension.ToLower() == ".jpg" || fileExtension.ToLower() == ".gif"
                || fileExtension.ToLower() == ".png" || fileExtension.ToLower() == ".bmp")
            {
                if (fileSize < 2097152)
                {
                    Stream stream = postedFile.InputStream;
                    BinaryReader binaryReader = new BinaryReader(stream);
                    Byte[] bytes = binaryReader.ReadBytes((int)stream.Length);

                    string ConnectionString = ConfigurationManager.ConnectionStrings["EMSConnectionString"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(ConnectionString))
                    {
                        SqlCommand cmd = new SqlCommand("spRegisterFaculty", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        string encryptedpassword = FormsAuthentication.HashPasswordForStoringInConfigFile(txtSPass.Text, "SHA1");

                        cmd.Parameters.AddWithValue("@FName", txtSFName.Text);
                        cmd.Parameters.AddWithValue("@LName", txtSLName.Text);
                        cmd.Parameters.AddWithValue("@Username", txtSUsername.Text);
                        cmd.Parameters.AddWithValue("@Password", encryptedpassword);
                        cmd.Parameters.AddWithValue("@Email", txtSEmail.Text);
                        cmd.Parameters.AddWithValue("@Mobile", txtSMobile.Text);
                        cmd.Parameters.AddWithValue("@DOB", txtSDOB.Text);

                        SqlParameter paramImageName = new SqlParameter()
                        {
                            ParameterName = @"ImageName",
                            Value = filename
                        };
                        cmd.Parameters.Add(paramImageName);

                        SqlParameter paramSize = new SqlParameter()
                        {
                            ParameterName = "@Size",
                            Value = fileSize
                        };
                        cmd.Parameters.Add(paramSize);

                        SqlParameter paramImageData = new SqlParameter()
                        {
                            ParameterName = "@ImageData",
                            Value = bytes
                        };

                        cmd.Parameters.Add(paramImageData);

                        con.Open();


                        int ReturnCode = (int)cmd.ExecuteScalar();
                        if (ReturnCode == -1)
                        {
                            lblMessage.Text = "User Name already in use, please choose another user name";
                        }
                        else
                        {
                            cmd.ExecuteNonQuery();
                            /*
                            MailMessage mailMessage = new MailMessage("codewithprogrammer@gmail.com", txtSEmail.Text);

                            mailMessage.Body = "Hello, " + txtSFName.Text + " " + txtSLName.Text + "\n\tYou are successfully registration on E mentoring system.\n\nWith Regards,\ncodewithprogrammer.";

                            mailMessage.Subject = "E Mentoring System Registration";

                            SmtpClient smtpClient = new SmtpClient();

                            smtpClient.Send(mailMessage);*/

                            lblMessage.Text = "Successfully added.";
                        }
                    }
                }
                else
                {
                    lblMessage.ForeColor = Color.Red;
                    lblMessage.Text = "Image size more than 2 MB not allowed.";
                }
            }
            else
            {
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "Image file not having .png, .jpg, .bmp, .gif extension.";
            }
        }
    }
}