﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Users_Student : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateGridview();
    }
    void PopulateGridview()
    {
        DataTable dt = new DataTable();
        string CS = ConfigurationManager.ConnectionStrings["EMSConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select StudId,FName,LName,Username,Password,Email,Mobile,GraduationType,Course,Class,ImageData,DOB,IsLocked,LockedDateTime From tblStudent", con);
            da.Fill(dt);
        }
        if (dt.Rows.Count > 0)
        {
            gvStudentData.DataSource = dt;
            gvStudentData.DataBind();
        }
        else
        {
            dt.Rows.Add(dt.NewRow());
            gvStudentData.DataSource = dt;
            gvStudentData.DataBind();
            gvStudentData.Rows[0].Cells.Clear();
            gvStudentData.Rows[0].Cells.Add(new TableCell());
            gvStudentData.Rows[0].Cells[0].ColumnSpan = dt.Columns.Count;
            gvStudentData.Rows[0].Cells[0].Text = "No Data Found ..!";
            gvStudentData.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
        }

    }

    protected void gvStudentData_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName.Equals("AddNew"))
            {
                string CS = ConfigurationManager.ConnectionStrings["EMSConnectionString"].ConnectionString;
                using (SqlConnection sqlCon = new SqlConnection(CS))
                {
                    sqlCon.Open();
                    string query = "INSERT INTO PhoneBook (FirstName,LastName,Contact,Email) VALUES (@FirstName,@LastName,@Contact,@Email)";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    sqlCmd.Parameters.AddWithValue("@FirstName", (gvStudentData.FooterRow.FindControl("txtFirstNameFooter") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@LastName", (gvStudentData.FooterRow.FindControl("txtLastNameFooter") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Contact", (gvStudentData.FooterRow.FindControl("txtContactFooter") as TextBox).Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Email", (gvStudentData.FooterRow.FindControl("txtEmailFooter") as TextBox).Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    PopulateGridview();
                    lblSuccessMessage.Text = "New Record Added";
                    lblErrorMessage.Text = "";
                }
            }
        }
        catch (Exception ex)
        {
            lblSuccessMessage.Text = "";
            lblErrorMessage.Text = ex.Message;
        }
    }
    protected void gvStudentData_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvPhoneBook.EditIndex = e.NewEditIndex;
        PopulateGridview();
    }
    protected void gvStudentData_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvPhoneBook.EditIndex = -1;
        PopulateGridview();
    }
    protected void gvStudentData_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                string query = "UPDATE PhoneBook SET FirstName=@FirstName,LastName=@LastName,Contact=@Contact,Email=@Email WHERE PhoneBookID = @id";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@FirstName", (gvPhoneBook.Rows[e.RowIndex].FindControl("txtFirstName") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@LastName", (gvPhoneBook.Rows[e.RowIndex].FindControl("txtLastName") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Contact", (gvPhoneBook.Rows[e.RowIndex].FindControl("txtContact") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Email", (gvPhoneBook.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text.Trim());
                sqlCmd.Parameters.AddWithValue("@id", Convert.ToInt32(gvPhoneBook.DataKeys[e.RowIndex].Value.ToString()));
                sqlCmd.ExecuteNonQuery();
                gvPhoneBook.EditIndex = -1;
                PopulateGridview();
                lblSuccessMessage.Text = "Selected Record Updated";
                lblErrorMessage.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblSuccessMessage.Text = "";
            lblErrorMessage.Text = ex.Message;
        }
    }
    protected void gvStudentData_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                string query = "DELETE FROM PhoneBook WHERE PhoneBookID = @id";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@id", Convert.ToInt32(gvPhoneBook.DataKeys[e.RowIndex].Value.ToString()));
                sqlCmd.ExecuteNonQuery();
                PopulateGridview();
                lblSuccessMessage.Text = "Selected Record Deleted";
                lblErrorMessage.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblSuccessMessage.Text = "";
            lblErrorMessage.Text = ex.Message;
        }
    }
}