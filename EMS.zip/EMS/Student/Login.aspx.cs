﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

public partial class Student_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        AuthenticateUser(txtLoginUsername.Text, txtLoginPass.Text);
    }
    private void AuthenticateUser(string username, string password)
    {
        // ConfigurationManager class is in System.Configuration namespace
        string CS = ConfigurationManager.ConnectionStrings["EMSConnectionString"].ConnectionString;



        // SqlConnection is in System.Data.SqlClient namespace
        using (SqlConnection con = new SqlConnection(CS))
        {
            SqlCommand cmd = new SqlCommand("spAuthenticateUser", con);
            cmd.CommandType = CommandType.StoredProcedure;

            //Formsauthentication is in system.web.security

            //sqlparameter is in System.Data namespace
            SqlParameter paramUsername = new SqlParameter("@Username", username);
            string encryptedpassword = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "SHA1");

            SqlParameter paramPassword = new SqlParameter("@Password", encryptedpassword);

            cmd.Parameters.Add(paramUsername);
            cmd.Parameters.Add(paramPassword);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                int RetryAttempt = Convert.ToInt32(dr["RetryAttempt"]);
                if (Convert.ToBoolean(dr["AccountLocked"]))
                {
                    lblLoginError.Text = "Account locked. Please contact administrator";
                }
                else if (RetryAttempt > 0)
                {
                    int AttemptsLeft = (4 - RetryAttempt);
                    lblLoginError.Text = "Invalid user name and/or password. " +
                        AttemptsLeft.ToString() + "attempt(s) left";
                }
                else if (Convert.ToBoolean(dr["Authenticated"]))
                {
                    Session["Username"] = txtLoginUsername.Text;
                    Response.Cookies["Username"].Value = txtLoginUsername.Text;
                    Response.Cookies["Password"].Value = txtLoginPass.Text;

                    Response.Cookies["Username"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["Password"].Expires = DateTime.Now.AddDays(1);
                    FormsAuthentication.RedirectFromLoginPage(txtLoginUsername.Text, chkRemember.Checked);
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    lblLoginError.Text = "Invalid User Name and/or Pasword";
                }
            }
        }
    }
}