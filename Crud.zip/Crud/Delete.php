<?php

include_once 'Crud.php';

$crud = new Crud();

$id = $crud->escapeString($_GET['id']);

$query = "delete from tbluser where ID = $id";

$result = $crud->executeQuery($query);

if($result){
    header("Location:index.php");
}

?>

