<?php

include_once 'Crud.php';

$crud = new Crud();

$query = "select * from tbluser";

$result = $crud->select($query);

?>

