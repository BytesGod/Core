<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Add Data</title>
    </head>
    <body>
        <a href="index.php">Home</a>
        
        <form action="AddData.php" method="POST">
            <table border="0">
                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email"></td>
                </tr>
                <tr>
                    <td>Mobile</td>
                    <td><input type="text" name="mobile"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="Submit" value="AddData"></td>
                </tr>
            </table>

        </form>
        
    </body>
</html>
