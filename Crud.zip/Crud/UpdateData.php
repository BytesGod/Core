<?php

include_once 'Crud.php';

$crud = new Crud();

if(isset($_POST['update']))
{
    $id = $crud->escapeString($_POST['id']);
    $name = $crud->escapeString($_POST['name']);
    $email = $crud->escapeString($_POST['email']);
    $mobile = $crud->escapeString($_POST['mobile']);
    
    $query = "update tbluser set Name = '$name', Email = '$email', Mobile = $mobile where ID = $id ";
    
    $result = $crud->executeQuery($query);
    if($result){
        header("Location:index.php");
    }
}

?>
