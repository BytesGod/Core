<?php

class Connection
{
    private $host = "localhost";
    private $user = "root";
    private $password = "";
    private $dbname = "test";
    
    protected $con;
    
    public function __construct() {
        if(!isset($this->con)){
            $this->con = mysqli_connect($this->host, $this->user, $this->password, $this->dbname);
            
            if(!$this->con){
                echo "Can't connect to database server.";
                exit();
            }
        }
        return $this->con;
    }
}

?>